<script src="<?php echo base_url();?>assets/js/jquery-3.4.1.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery-ui.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url();?>assets/js/isotope-3.0.6.min.js"></script>
<script src="<?php echo base_url();?>assets/js/chosen.min.js"></script>
<script src="<?php echo base_url();?>assets/js/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/js/daterangepicker.js"></script>
<script src="<?php echo base_url();?>assets/js/purecounter.js"></script>
<script src="<?php echo base_url();?>assets/js/particles.min.js"></script>
<script src="<?php echo base_url();?>assets/js/particles-script.js"></script>
<script src="<?php echo base_url();?>assets/js/progresscircle.js"></script>
<script src="<?php echo base_url();?>assets/js/main.js"></script>

