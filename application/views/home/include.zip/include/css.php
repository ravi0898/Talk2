<!-- Favicon -->
<link rel="icon" href="<?php echo base_url();?>assets/images/talk2-logo.png">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Noto+Sans+JP:100,300,400,500,700,900&amp;display=swap" rel="stylesheet">

<!-- Template CSS Files -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/line-awesome.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.theme.default.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/magnific-popup.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/daterangepicker.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/chosen.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">